<?php

$HOST = 'localhost';
$USER = 'root';
$PASS = '';
$DB = 'db_simplecrud';

$CON = mysqli_connect($HOST,$USER,$PASS,$DB);

?>
